import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

/**
  *
  * Beschreibung
  *
  * @version 1.0 vom 11.01.2021
  * @author 
  */

public class TicTacToe extends JFrame {
  // Anfang Attribute
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private JButton jButton3 = new JButton();
  private JButton jButton4 = new JButton();
  private JButton jButton5 = new JButton();
  private JButton jButton6 = new JButton();
  private JButton jButton7 = new JButton();
  private JButton jButton8 = new JButton();
  private JButton jButton9 = new JButton();
  private JButton jButton10 = new JButton();
  private JButton jButton11 = new JButton();
  private JTextField jTextField1 = new JTextField();
  private JTextField jTextField2 = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  // Ende Attribute
  
  public TicTacToe(String title) { 
    // Frame-Initialisierung
    super(title);
    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    int frameWidth = 250; 
    int frameHeight = 200;
    setSize(frameWidth, frameHeight);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (d.width - getSize().width) / 2;
    int y = (d.height - getSize().height) / 2;
    setLocation(x, y);
    setResizable(false);
    Container cp = getContentPane();
    cp.setLayout(null);
    
    
    // Anfang Komponenten
    
    jButton1.setBounds(8, 8, 25, 25);
    jButton1.setText("T");
    jButton1.setEnabled(false);
    jButton1.setMargin(new Insets(2, 2, 2, 2));
    jButton1.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        jButton1_ActionPerformed(evt);
        if (slot1 == '1') {
          if (isX) {
            slot1 = 'X';
            jButton1.setText("X");
            isX = false;
          } else {
            slot1 = 'O';
            jButton1.setText("O");
            isX = true;
          } // end of if-else
          winDetection();
        } // end of if
      }
    });
    cp.add(jButton1);
    jButton2.setBounds(40, 8, 25, 25);
    jButton2.setText("I");
    jButton2.setEnabled(false);
    jButton2.setMargin(new Insets(2, 2, 2, 2));
    jButton2.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        jButton2_ActionPerformed(evt);
        if (slot2 == '2') {
          if (isX) {
            slot2 = 'X';
            jButton2.setText("X");
            isX = false;
          } else {
            slot2 = 'O';
            jButton2.setText("O");
            isX = true;
          } // end of if-else
          winDetection();
        } // end of if
      }
    });
    cp.add(jButton2);
    jButton3.setBounds(72, 8, 25, 25);
    jButton3.setText("C");
    jButton3.setEnabled(false);
    jButton3.setMargin(new Insets(2, 2, 2, 2));
    jButton3.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        jButton3_ActionPerformed(evt);
        if (slot3 == '3') {
          if (isX) {
            slot3 = 'X';
            jButton3.setText("X");
            isX = false;
          } else {
            slot3 = 'O';
            jButton3.setText("O");
            isX = true;
          } // end of if-else
          winDetection();
        } // end of if
      }
    });
    cp.add(jButton3);
    jButton4.setBounds(8, 40, 25, 25);
    jButton4.setText("T");
    jButton4.setEnabled(false);
    jButton4.setMargin(new Insets(2, 2, 2, 2));
    jButton4.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        jButton4_ActionPerformed(evt);
        if (slot4 == '4') {
          if (isX) {
            slot4 = 'X';
            jButton4.setText("X");
            isX = false;
          } else {
            slot4 = 'O';
            jButton4.setText("O");
            isX = true;
          } // end of if-else
          winDetection();
        } // end of if
      }
    });
    cp.add(jButton4);
    jButton5.setBounds(40, 40, 25, 25);
    jButton5.setText("A");
    jButton5.setEnabled(false);
    jButton5.setMargin(new Insets(2, 2, 2, 2));
    jButton5.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        jButton5_ActionPerformed(evt);
        if (slot5 == '5') {
          if (isX) {
            slot5 = 'X';
            jButton5.setText("X");
            isX = false;
          } else {
            slot5 = 'O';
            jButton5.setText("O");
            isX = true;
          } // end of if-else
          winDetection();
        } // end of if
      }
    });
    cp.add(jButton5);
    jButton6.setBounds(72, 40, 25, 25);
    jButton6.setText("C");
    jButton6.setEnabled(false);
    jButton6.setMargin(new Insets(2, 2, 2, 2));
    jButton6.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        jButton6_ActionPerformed(evt);
        if (slot6 == '6') {
          if (isX) {
            slot6 = 'X';
            jButton6.setText("X");
            isX = false;
          } else {
            slot6 = 'O';
            jButton6.setText("O");
            isX = true;
          } // end of if-else
          winDetection();
        } // end of if
      }
    });
    cp.add(jButton6);
    jButton7.setBounds(8, 72, 25, 25);
    jButton7.setText("T");
    jButton7.setEnabled(false);
    jButton7.setMargin(new Insets(2, 2, 2, 2));
    jButton7.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        jButton7_ActionPerformed(evt);
        if (slot7 == '7') {
          if (isX) {
            slot7 = 'X';
            jButton7.setText("X");
            isX = false;
          } else {
            slot7 = 'O';
            jButton7.setText("O");
            isX = true;
          } // end of if-else
          winDetection();
        } // end of if
      }
    });
    cp.add(jButton7);
    jButton8.setBounds(40, 72, 25, 25);
    jButton8.setText("O");
    jButton8.setEnabled(false);
    jButton8.setMargin(new Insets(2, 2, 2, 2));
    jButton8.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        jButton8_ActionPerformed(evt);
        if (slot8 == '8') {
          if (isX) {
            slot8 = 'X';
            jButton8.setText("X");
            isX = false;
          } else {
            slot8 = 'O';
            jButton8.setText("O");
            isX = true;
          } // end of if-else
          winDetection();
        } // end of if
      }
    });
    cp.add(jButton8);
    jButton9.setBounds(72, 72, 25, 25);
    jButton9.setText("E");
    jButton9.setEnabled(false);
    jButton9.setMargin(new Insets(2, 2, 2, 2));
    jButton9.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        jButton9_ActionPerformed(evt);
        if (slot9 == '9') {
          if (isX) {
            slot9 = 'X';
            jButton9.setText("X");
            isX = false;
          } else {
            slot9 = 'O';
            jButton9.setText("O");
            isX = true;
          } // end of if-else
          winDetection();
        } // end of if
      }
    });
    cp.add(jButton9);
    jButton10.setBounds(8, 104, 89, 25);
    jButton10.setText("RESET");
    jButton10.setEnabled(false);
    jButton10.setMargin(new Insets(2, 2, 2, 2));
    jButton10.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        jButton10_ActionPerformed(evt);
          jButton10.setEnabled(false);
          jButton11.setEnabled(true);
          game(false);
          jButton1.setText("T");
          jButton2.setText("I");
          jButton3.setText("C");
          jButton4.setText("T");
          jButton5.setText("A");
          jButton6.setText("C");
          jButton7.setText("T");
          jButton8.setText("O");
          jButton9.setText("E");
          isGameRunning = false;
          isX = true;
          slot1 = '1';
          slot2 = '2';
          slot3 = '3';
          slot4 = '4';
          slot5 = '5';
          slot6 = '6';
          slot7 = '7';
          slot8 = '8';
          slot9 = '9';
          jLabel1.setText("TicTacToe");
          jLabel2.setText("");
          isWin = false;
          winner = 'P';
          jTextField1.setEditable(true);
          jTextField2.setEditable(true);
      }
    });
    cp.add(jButton10);
    jButton11.setBounds(104, 104, 89, 25);
    jButton11.setText("START");
    jButton11.setMargin(new Insets(2, 2, 2, 2));
    jButton11.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        if (isGameRunning == false) {
          isGameRunning = true;
          jButton11.setEnabled(false);
          jButton10.setEnabled(true);
          game(true);
          jButton1.setText("");
          jButton2.setText("");
          jButton3.setText("");
          jButton4.setText("");
          jButton5.setText("");
          jButton6.setText("");
          jButton7.setText("");
          jButton8.setText("");
          jButton9.setText("");
          jTextField1.setEditable(false);
          jTextField2.setEditable(false);
          playerX = jTextField1.getText();
          playerO = jTextField2.getText();
        } // end of if
      }
    });
    cp.add(jButton11);
    
    jTextField1.setBounds(104, 8, 89, 25);
    jTextField1.setText ("Spieler X");
    cp.add(jTextField1);
    
    jTextField2.setBounds(104, 40, 89, 25);
    jTextField2.setText ("Spieler O");
    cp.add(jTextField2);
    
    jLabel1.setBounds(104, 72, 91, 25);
    jLabel1.setText("TicTacToe");
    cp.add(jLabel1);
    
    jLabel2.setBounds(8, 136, 187, 25);
    jLabel2.setText("");
    cp.add(jLabel2);
    // Ende Komponenten
    
    setVisible(true);
  } // end of public TicTacToe
  // Meine Variablen
  char slot1 = '1', slot2 = '2', slot3 = '3', slot4 = '4', slot5 = '5', slot6 = '6', slot7 = '7', slot8 = '8', slot9 = '9', winner;
  boolean isGameRunning = false, isX = true, isWin = false, state = false;
  String playerX, playerO;
  // Anfang Methoden
  
  public static void main(String[] args) {
    new TicTacToe("TicTacToe");
  } // end of main
  
  public void game(boolean state) {
    jButton1.setEnabled(state);
    jButton2.setEnabled(state);
    jButton3.setEnabled(state);
    jButton4.setEnabled(state);
    jButton5.setEnabled(state);
    jButton6.setEnabled(state);
    jButton7.setEnabled(state);
    jButton8.setEnabled(state);
    jButton9.setEnabled(state);
  }
  
  public void winDetection() {
    if ((slot1 == slot2)&&(slot1 == slot3)) {
      isWin = true;
      winner = slot1;
    } // end of if
    
    if ((slot4 == slot5)&&(slot4 == slot6)) {
      isWin = true;
      winner = slot4;
    } // end of if
    
    if ((slot7 == slot8)&&(slot7 == slot9)) {
      isWin = true;
      winner = slot7;
    } // end of if
    
    if ((slot1 == slot4)&&(slot1 == slot7)) {
      isWin = true;
      winner = slot1;
    } // end of if
    
    if ((slot2 == slot5)&&(slot2 == slot8)) {
      isWin = true;
      winner = slot2;
    } // end of if
    
    if ((slot3 == slot6)&&(slot3 == slot9)) {
      isWin = true;
      winner = slot3;
    } // end of if
    
    if ((slot1 == slot5)&&(slot1 == slot9)) {
      isWin = true;
      winner = slot1;
    } // end of if
    
    if ((slot3 == slot5)&&(slot3 == slot7)) {
      isWin = true;
      winner = slot5;
    } // end of if
    
    if (isWin) {
      if (winner == 'X') {
        jLabel2.setText(playerX + " hat gewonnen!");  
      } else {
        jLabel2.setText(playerO + " hat gewonnen!");
      } // end of if-else
      isGameRunning = false;
      game(false);
    } // end of if
  }
  
  
  public void jButton1_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
  } // end of jButton1_ActionPerformed
  
  public void jButton2_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
  } // end of jButton2_ActionPerformed
  
  public void jButton3_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
  } // end of jButton3_ActionPerformed
  
  public void jButton4_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
  } // end of jButton4_ActionPerformed
  
  public void jButton5_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
  } // end of jButton5_ActionPerformed
  
  public void jButton6_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
  } // end of jButton6_ActionPerformed
  
  public void jButton7_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
  } // end of jButton7_ActionPerformed
  
  public void jButton8_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
  } // end of jButton8_ActionPerformed
  
  public void jButton9_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
  } // end of jButton9_ActionPerformed
  
  public void jButton10_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
  } // end of jButton10_ActionPerformed
  
  public void jButton11_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
  } // end of jButton11_ActionPerformed
  
  // Ende Methoden
} // end of class TicTacToe
